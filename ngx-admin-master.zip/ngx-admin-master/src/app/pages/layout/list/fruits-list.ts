export const fruits: string[] = [
  'Lemons',
  'Raspberries',
  'Strawberries',
  'Blackberries',
  'Kiwis',
  'Grapefruit',
  'Avocado',
  'Watermelon',
  'Cantaloupe',
  'Oranges',
  'Peaches',
];
